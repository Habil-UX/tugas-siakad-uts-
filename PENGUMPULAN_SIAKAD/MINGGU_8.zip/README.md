# Tugas SIAKAD Minggu 8 — Observer, Outbox, KRSInvalidator, & Ekspor .ics

## Checklist Akhir Minggu 8 (Sesuai Slide PBO Minggu 08)
1. **ScheduleSubject + 3 Observer + Email/SMS/Push (log):** pp/observers/schedule_subject.py, pp/observers/concrete_observers.py, pp/observers/outbox.py (EmailChannel, SMSChannel, PushChannel yang dapat ditukar + 	ry/except per observer).
2. **Outbox + OutboxDispatcher setelah commit:** pp/observers/outbox.py (Outbox, OutboxDispatcher.dispatch_after_commit(), deduplikasi idempotency_key).
3. **KRSInvalidator + transisi Actor.SISTEM + test 42 ilegal:** pp/services/krs_invalidator.py, pp/services/krs_state_machine.py (Actor.MAHASISWA, Actor.DOSEN_PA, Actor.SISTEM), dan 	ests/test_week8_checklist.py (menguji tepat 42 transisi ilegal & 6 transisi legal).
4. **Prompt Step 3 + saring_saran + Conflict Resolver:** pp/services/rescheduling_service.py (PROMPT_STEP_3, saring_saran) & dashboard /dashboard.
5. **Sequence diagram di docs/ & ekspor .ics:** docs/diagram/observer-sequence.mmd, pp/utils/ics_exporter.py, endpoint GET /api/schedules/export.ics.
6. **Unit Tests, AI Log + OPAR, & PR Template:** 	ests/test_week8_checklist.py, AI_USAGE_LOG.md, OPAR.md, PR_TEMPLATE.md.

## Cara Menjalankan Test
`ash
pytest tests/test_week8_checklist.py tests/test_scheduling.py -q
`
