# Tugas SIAKAD Minggu 9 — GradeService, PresensiPort, NilaiRepo, & GPACalculator

## Checklist Tugas Minggu 9 (Sesuai Slide PBO Minggu 09)
1. **Migration (FK krs_detail.nilai, skala_nilai.lulus, grade_history):** lembic/versions/95417f7b9188_add_grade_management_and_audit_trail.py & pp/models/krs_models.py (lulus = data).
2. **GradeService + PUT /api/kelas/{id}/nilai/{nim} + form sederhana:** pp/services/grade_service.py, pp/routers/grades.py, & halaman /grades-ui.
3. **PresensiPort + PresensiStub & is_pengampu:** pp/services/presensi_port.py (validasi kehadiran >= 75% & otorisasi dosen pengampu 403 Forbidden).
4. **hitung_ips/hitung_ipk + NilaiRepo + GPACalculator & view riwayat:** pp/services/nilai_repo.py, pp/services/gpa_calculator.py (Decimal, ROUND_HALF_UP sekali di akhir, terbaik per kode_mk, _grade_history).
5. **10+ kasus parametrize + 3 properti Hypothesis:** 	ests/test_week9_checklist.py (12 kasus parametrize + 3 properti Hypothesis) & 	ests/test_transcript_service.py (14 kasus parametrize).
6. **Pertanyaan ke stakeholder, ADR, AI Log + OPAR:** docs/week9-10/PERTANYAAN_STAKEHOLDER.md, docs/week9-10/ADR-001-Audit-Trail.md, AI_USAGE_LOG.md, OPAR.md.

## Cara Menjalankan Test
`ash
pytest tests/test_week9_checklist.py tests/test_grade_service.py tests/test_transcript_service.py -q
`
