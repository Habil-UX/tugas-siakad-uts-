# Tugas SIAKAD Minggu 10 — Nilai & Transkrip Bagian 2 (HTML/PDF & Acceptance Multi-Semester)

## Checklist Tugas Minggu 10 (Sesuai Slide PBO Minggu 09 — Bagian 2)
1. **get_transcript(nim) — catatan akademik lengkap:** pp/services/transcript_service.py & pp/services/gpa_calculator.py (biodata, tampilan historis per semester, IPS tiap semester, IPK kumulatif Decimal ROUND_HALF_UP, total SKS lulus).
2. **Transkrip PDF dari template HTML (ReportLab & HTML Template):** pp/templates/transcript.html, pp/utils/pdf_generator.py (
ender_transcript_html & generate_transcript_pdf), endpoint GET /api/grades/transcript/{nim}/html dan GET /api/grades/transcript/{nim}/pdf.
3. **Predikat kelulusan di footer & tampilan historis:** Tampil pada footer HTML template dan dokumen PDF Transkrip Akademik resmi beserta tanda tangan Dekan.
4. **Acceptance test multi-semester & rekap deliverable:** 	ests/test_week10_acceptance.py (menguji 4 semester penuh, pengulangan MK lintas semester, revisi nilai + audit trail, HTML template, & binary PDF valid).

## Cara Menjalankan Test
`ash
pytest tests/test_week10_acceptance.py tests/test_pdf_generator.py tests/test_transcript_service.py -q
`
